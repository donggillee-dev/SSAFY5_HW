
$(function() {
	// 아이디 중복체크
	var canIdTag = $("<p> 사용가능한 아이디입니다. </p>");
	var cannotIdTag = $("<p> 사용불가한 아이디입니다. 다시 입력하세요. </p>");
	var isPossible = false;

	$("#inputId").keyup(function() {
		$("#idCheck").empty();
		if ($("#inputId").val() == "") $("#idCheck").empty();
		else {
			$.ajax({
				url: 'userlist.xml',
				cache: false,
				dataType: "xml",
				success: function(data) {
					let userid = $("#inputId").val();
					let flag = 1;
					$(data).find("user").each(function() {
						let id = $(this).find("id").text();
						if (userid == id) {
							$("#idCheck").css('color', 'red');
							$("#idCheck").append(cannotIdTag);
							flag = 0;
							isPossible = false;
							return false;
						}
					});
					if (flag == 1) {
						isPossible = true;
						$("#idCheck").css('color', 'green');
						$("#idCheck").append(canIdTag);
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("error : " + textStatus + "\n" + errorThrown);
				}
			});
		}
	})

	// 회원 가입 처리
	$('#join-submit')
		.click(
			function() {
				if ($("#inputName").val() == '') {
					alert('이름을 입력하세요');
					$("#inputName").focus();
					return false;
				}

				var email = $('#inputEmail').val();
				if (email == '') {
					alert('이메일을 입력하세요');
					$("#inputEmail").focus();
					return false;
				} else {
					var emailRegex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
					if (!emailRegex.test(email)) {
						alert('이메일 주소가 유효하지 않습니다. ex)abc@gmail.com');
						$("#inputEmail").focus();
						return false;
					}
				}

				if ($("#inputPw").val() == '') {
					alert('비밀번호를 입력하세요');
					$("#inputPw").focus();
					return false;
				}

				if ($("#inputPwConfirm").val() == '') {
					alert('비밀번호를 다시 한번 더 입력하세요');
					$("#inputPwConfirm").focus();
					return false;
				}

				if ($("#inputPw").val() !== $("#inputPwConfirm").val()) {
					alert('비밀번호를 둘다 동일하게 입력하세요');
					return false;
				}

				if ($("#inputPhone").val() == '') {
					alert('휴대폰 번호를 입력하세요');
					$("#inputPhone").focus();
					return false;
				}

				if (isPossible == false) {
					alert(' 아이디가 중복됩니다 확인해주세요 ! ');
					$("#inputId").focus();
					return false;
				}
				else { alert(' 회원가입 성공 ! '); }
			});

	// 로그인처리
	$('#login-btn').click(function() {
		loginId = $('#loginId').val();
		loginPw = $('#loginPw').val();
		$.ajax({
			url: 'userlist.xml',
			type: 'GET',
			dataType: 'xml',
			success: function(response) {
				checkLogin(response);
			},
			error: function(jqXHR, textStatus, errorThrown) {
				console.log("error : " + textStatus + "\n" + errorThrown);
			}
		});
	});
	// 로그아웃처리
	$("#logout").click(function() {
		$("#logout").hide();
		$("#login").show();
	})
	// 아이디-비밀번호 매치 확인
	function checkLogin(data) {
		var canLogin = false;
		$(data).find('user').each(
			function() {
				if ($(this).find("id").text() == loginId
					&& $(this).find("password").text() == loginPw) {
					alert(' 로그인 성공 ! ');
					$("#myName").text(loginId);
					$("#logout").show();
					$("#login").hide();
					canLogin = true;
					return false;
				}
			});
		if (!canLogin) {
			alert(' 아이디와 비밀번호를 확인하세요 ! ');
		}
	}
});