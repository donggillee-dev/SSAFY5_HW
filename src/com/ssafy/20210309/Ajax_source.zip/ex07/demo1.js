function setName(param){
	return "당신의 이름은 <b>" + param + "<b>입니다";	
}