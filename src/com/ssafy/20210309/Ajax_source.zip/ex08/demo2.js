function addMethod(data1, data2)
{
	       // "5" --> 5      "7" --> 7
	var rs=parseInt(data1) + parseInt(data2);
	//var rs=data1+data2;
	
	return "두수의 합은 <b>" + rs + "</b>입니다";	
}