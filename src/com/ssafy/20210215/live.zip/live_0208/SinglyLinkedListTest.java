package live_0208;

public class SinglyLinkedListTest {
	public static void main(String[] args) {
		SinglyLinkedList list = new SinglyLinkedList();

		list.addLastNode("A");
		System.out.println(list.getLastNode());
		list.printList();
		
		list.addLastNode("B");
		list.printList();
		
		list.addFirstNode("C");
		list.printList();
		
		Node preNode = list.getNode("A");
		list.insertAfterNode(preNode, "D");
		list.printList();

		System.out.println(list.getPreviousNode(list.getNode("B")));
		
		list.deleteNode("A");
		list.printList();
		
		list.deleteNode("B");
		list.printList();
		
		list.deleteNode("C");
		list.printList();	
		
		list.deleteNode("D");
		list.printList();		

	}
}
