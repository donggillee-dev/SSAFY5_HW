package live_0209;

import java.util.LinkedList;
import java.util.Queue;

public class CompleteBinaryTree {

	private char[] nodes;
	private int lastIndex;
	private final int SIZE;
	
	public CompleteBinaryTree(int size){
		super();
		SIZE = size;
		nodes = new char[size+1];// 0인덱스 사용 안함
	}
	
	public boolean isEmpty(){
		return lastIndex == 0;
	}
	
	private boolean isFull(){
		return lastIndex == SIZE;
	}
	
	//완전이진트리로 추가하는 방법
	public void add(char e){
		if(isFull()){
			System.out.println("포화상태입니다..");
			return;
		}
		nodes[++lastIndex] = e;
	}
	public void bfs() {
		if(isEmpty())	return;
		
		Queue<Integer>  queue = new LinkedList<Integer>();
		queue.offer(1);
		int current;
		while(!queue.isEmpty()) {
			current = queue.poll();
			System.out.println(nodes[current]);
			if(current*2<=lastIndex) queue.offer(current*2);
			if(current*2+1<=lastIndex) queue.offer(current*2+1);
		}		
	}
	public void bfs2() {
		if(isEmpty())	return;
		
		//탐색순서번호를 큐로 관리
		Queue<Integer>  queue = new LinkedList<Integer>();
		queue.offer(1);
		int current,size,level=0;
		
		while(!queue.isEmpty()) {
			size = queue.size();
			System.out.print("level"+level+" : ");
			while(--size>=0) {
				current = queue.poll();
				System.out.print(nodes[current]);
				if(current*2<=lastIndex) queue.offer(current*2);
				if(current*2+1<=lastIndex) queue.offer(current*2+1);				
			}
			System.out.println();
			++level;
		}		
	}
	
	//전위 순회----------------------------------------------
	public void dfs(int current) {
		if(current > lastIndex) return;
		//VLR
		System.out.println(nodes[current]);  //방문관련처리
		dfs(current*2);
		dfs(current*2+1);
	}
	//중위 순회----------------------------------------------
	public void dfs2(int current) {
		if(current > lastIndex) return;
		//LVR
		dfs(current*2);
		System.out.println(nodes[current]);  //방문관련처리
		dfs(current*2+1);
	}
	//후위 순회----------------------------------------------
	public void dfs3(int current) {
		if(current > lastIndex) return;
		//LRV
		dfs(current*2);
		dfs(current*2+1);
		System.out.println(nodes[current]);  //방문관련처리
	}
}











