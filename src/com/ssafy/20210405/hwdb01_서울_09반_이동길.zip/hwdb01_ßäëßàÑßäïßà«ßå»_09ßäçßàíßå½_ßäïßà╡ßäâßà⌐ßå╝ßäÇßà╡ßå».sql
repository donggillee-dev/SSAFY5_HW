#1
CREATE TABLE `product` (
  `product_no` int NOT NULL AUTO_INCREMENT,
  `product_name` varchar(30) NOT NULL,
  `product_price` int NOT NULL,
  PRIMARY KEY (`product_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#2
INSERT INTO product(product_name, product_price) VALUES('TV1', 2000000);
INSERT INTO product(product_name, product_price) VALUES('TV2', 3500000);
INSERT INTO product(product_name, product_price) VALUES('TV3', 4200000);
INSERT INTO product(product_name, product_price) VALUES('NoteBook1', 1000000);
INSERT INTO product(product_name, product_price) VALUES('NoteBook2', 500000);

#3
select product_no as '상품코드', product_name as '상품명', round(product_price * 0.85) as '세일가격'
from product;

#4
update product
set product_price = round(product_price * 1.2)
where product_name LIKE '%TV%';

#5
select SUM(product_price) as total_price
from product;