#1
-- Inner Join
select E.ENAME as '이름',
       E.JOB   as '업무',
       E.SAL   as '급여'
from EMP E
         inner join DEPT D
                    on E.DEPTNO = D.DEPTNO
where D.LOC = 'CHICAGO';

-- SubQuery
select e.ENAME as '이름',
       e.JOB   as '업무',
       e.SAL   as '급여'
from EMP e
where DEPTNO = (
    select deptNO
    from DEPT
    where LOC = 'CHICAGO'
);

#2
select e1.EMPNO  as '사원번호',
       e1.ENAME  as '이름',
       e1.JOB    as '업무',
       e1.DEPTNO as '부서번호'
from EMP e1
         left outer join EMP e2
                         on e1.EMPNO = e2.MGR
where e2.EMPNO is null;

#3
select ENAME as '사원이름',
       JOB   as '업무',
       MGR   as '상사번호'
from EMP
where MGR = (
    select MGR
    from EMP
    where ENAME = 'BLAKE'
);

#4
select EMPNO as '사원번호',
       ENAME as '사원이름'
from EMP
ORDER BY HIREDATE
LIMIT 5;

#5
select e.ENAME as '이름',
       e.JOB   as '업무',
       d.DNAME as '부서명'
from EMP e
         inner join DEPT d
                    on e.DEPTNO = d.DEPTNO
         inner join (
                select EMPNO
                from EMP
                where ENAME = 'JONES'
            ) as jt
                    on e.MGR = jt.EMPNO;