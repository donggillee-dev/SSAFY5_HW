package com.ssafy.member.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/registerProduct.do")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String product_no = request.getParameter("product_no");
		String product_name = request.getParameter("product_name");
		String product_price = request.getParameter("product_price");
		String product_desc = request.getParameter("product_desc");
//		Cookie 설정
			Cookie cookie_no = new Cookie("product_no", product_no);
			cookie_no.setPath(request.getContextPath());
			cookie_no.setMaxAge(60 * 60 * 24 * 365 * 40);
			
			Cookie cookie_name = new Cookie("product_name", product_name);
			cookie_name.setPath(request.getContextPath());
			cookie_name.setMaxAge(60 * 60 * 24 * 365 * 40);
			
			Cookie cookie_price = new Cookie("product_price", product_price);
			cookie_price.setPath(request.getContextPath());
			cookie_price.setMaxAge(60 * 60 * 24 * 365 * 40);
			
			Cookie cookie_desc = new Cookie("product_desc", product_desc);
			cookie_desc.setPath(request.getContextPath());
			cookie_desc.setMaxAge(60 * 60 * 24 * 365 * 40);
			
			response.addCookie(cookie_no);
			response.addCookie(cookie_name);
			response.addCookie(cookie_price);
			response.addCookie(cookie_desc);
			
			String path = "index.jsp";
			RequestDispatcher disp = request.getRequestDispatcher(path);
			disp.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		doGet(request, response);
		
	}

}
