package com.ssafy.member.dto;

public class ProductDto {
	private int pid;
	private int cid;
	private int sid;
	private String pname;
	private int lprice;
	private int oprice;

	
	@Override
	public String toString() {
		return "ProductDto [pid=" + pid + ", cid=" + cid + ", sid=" + sid + ", pname=" + pname + ", lprice=" + lprice
				+ ", oprice=" + oprice + "]";
	}

	public ProductDto() {
		super();
	}

	public ProductDto(int pid, int cid, int sid, String pname, int lprice, int oprice) {
		super();
		this.pid = pid;
		this.cid = cid;
		this.sid = sid;
		this.pname = pname;
		this.lprice = lprice;
		this.oprice = oprice;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public int getLprice() {
		return lprice;
	}

	public void setLprice(int lprice) {
		this.lprice = lprice;
	}

	public int getOprice() {
		return oprice;
	}

	public void setOprice(int oprice) {
		this.oprice = oprice;
	}

}
