package com.ssafy.member.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssafy.common.JdbcTemplate;

@WebServlet("/registerProduct.do")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");

		//register.jsp로부터 post로 전달받은 데이터들 가공처리
		String category_id = request.getParameter("category_id");
		String supplier_id = request.getParameter("supplier_id");
		String product_name = request.getParameter("product_name");
		String product_price = request.getParameter("product_price");

		//Connection 생성
		Connection conn = JdbcTemplate.getConnection();
		PreparedStatement pstmt = null;
		int rs = -1;
		
		try {
			//Update SQL문구 설정
			String sql = "insert into product(category_id, supplier_id, product_name, list_price) values(?, ?, ?, ?)";

			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, Integer.parseInt(category_id));
			pstmt.setInt(2, Integer.parseInt(supplier_id));
			pstmt.setString(3, product_name);
			pstmt.setInt(4, Integer.parseInt(product_price));

			//SQL문 실행
			rs = pstmt.executeUpdate();

		} catch (Exception e) {
			//Update가 실패할 각종 예외상황들에 대해서 페이지 리로드 처리
			RequestDispatcher disp = request.getRequestDispatcher("/user/register.jsp");
			disp.forward(request, response);
			e.printStackTrace();

		} finally {
			JdbcTemplate.close(pstmt);
			JdbcTemplate.close(conn);
		}

		if (rs > 0) {
			//update가 성공한 경우 index페이지로 이동
			RequestDispatcher disp = request.getRequestDispatcher("/user/index.jsp");
			disp.forward(request, response);
		} else {
			//update가 실패한 경우 페이지 리로드
			RequestDispatcher disp = request.getRequestDispatcher("/user/register.jsp");
			disp.forward(request, response);
		}
	}

}
