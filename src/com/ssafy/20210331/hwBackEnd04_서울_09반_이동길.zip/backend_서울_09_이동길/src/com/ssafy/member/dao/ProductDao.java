package com.ssafy.member.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.common.JdbcTemplate;
import com.ssafy.member.dto.ProductDto;

//DAO(Data Access OBject):데이터베이스와 연동해서 CRUD 처리
public class ProductDao {
	public ProductDto getLastProduct() {
		Connection conn = JdbcTemplate.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ProductDto entity = null;

		try {
			String sql = "select * from product order by product_id desc limit 1";

			pstmt = conn.prepareStatement(sql);

			// SQL문 실행
			rs = pstmt.executeQuery();

			if (rs.next()) {
				entity = new ProductDto();
				entity.setPid(rs.getInt("product_id"));
				entity.setCid(rs.getInt("category_id"));
				entity.setSid(rs.getInt("supplier_id"));
				entity.setPname(rs.getString("product_name"));
				entity.setLprice(rs.getInt("list_price"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JdbcTemplate.close(rs);
			JdbcTemplate.close(pstmt);
			JdbcTemplate.close(conn);
		}

		return entity;
	}

	public List<ProductDto> getProductList() {
	      
	      List<ProductDto> list = new ArrayList<ProductDto>();
	      Connection conn = JdbcTemplate.getConnection();
	      PreparedStatement pstmt = null;
	      ResultSet rs = null;
	      try {
	         String sql = "select product_id, category_id, product_name, list_price \n";
	         sql += "from product \n";
	         pstmt = conn.prepareStatement(sql);
	         rs = pstmt.executeQuery();
	         while (rs.next()) {
	            ProductDto productDto = new ProductDto();
	            productDto.setPid(rs.getInt("product_id"));
	            productDto.setPname(rs.getString("product_name"));
	            productDto.setLprice(rs.getInt("list_price"));
	            productDto.setCid(rs.getInt("category_id"));
	            list.add(productDto);
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	      } finally {
	         try {
	            if(rs != null)
	               rs.close();
	            if(pstmt != null)
	               pstmt.close();
	            if(conn != null)
	               conn.close();
	         } catch (SQLException e) {
	            e.printStackTrace();
	         }
	      }
	      
	      return list;
	   }

	public void setProduct(ProductDto entity) {
		Connection conn = JdbcTemplate.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			String sql = "INSERT INTO product(category_id, supplier_id, product_name, list_price, order_price) "
					+ "VALUES (?, ?, ?, ?, ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, entity.getCid());
			pstmt.setInt(2, entity.getSid());
			pstmt.setString(3, entity.getPname());
			pstmt.setInt(4, entity.getLprice());
			pstmt.setInt(5, entity.getOprice());

			rs = pstmt.executeQuery();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JdbcTemplate.close(rs);
			JdbcTemplate.close(pstmt);
			JdbcTemplate.close(conn);
		}

		return;
	}
}
