CREATE TABLE `product` (
  `product_id` int NOT NULL,
  `category_id` int NOT NULL,
  `supplier_id` int NOT NULL,
  `product_name` varchar(45) NOT NULL,
  `list_price` int NOT NULL,
  `order_price` int DEFAULT NULL,
  PRIMARY KEY (`product_id`),
  UNIQUE KEY `product_id_UNIQUE` (`product_id`)
) DEFAULT CHARSET=utf8;

INSERT INTO `ssafyweb`.`product` (`product_id`, `category_id`, `supplier_id`, `product_name`, `list_price`, `order_price`) VALUES ('1', '1', '3030', '상품1', '3000', '1000');
INSERT INTO `ssafyweb`.`product` (`product_id`, `category_id`, `supplier_id`, `product_name`, `list_price`, `order_price`) VALUES ('2', '1', '3031', '상품2', '2000', '1000');
INSERT INTO `ssafyweb`.`product` (`product_id`, `category_id`, `supplier_id`, `product_name`, `list_price`, `order_price`) VALUES ('3', '2', '3032', '상품3', '5000', '3000');
