package constructorex;

class Example2{
	Example2(){
		System.out.println("default constructor");
	}
	Example2(String str){
		this();
		System.out.println(str+" constructor");
	}
	Example2(String str, int n){
		this(str);
		System.out.println(str+"  "+n +" constructor");
	}
}
public class ConstructorEx2 {
	public static void main(String[] args) {
		new Example2("Hello",100);
	}
}
