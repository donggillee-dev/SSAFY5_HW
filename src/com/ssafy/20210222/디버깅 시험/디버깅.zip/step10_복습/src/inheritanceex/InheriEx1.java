package inheritanceex;

class ParentEx{
	public void view() {
		System.out.println("parent class");
	}
}
class ChildEx extends ParentEx{
	public void view() {
		super.view();
		System.out.println("child class");
	}
}
public class InheriEx1 {
	public static void main(String[] args) {
		new ChildEx().view();
	}
}
//----------------------------------------------
/*
class ParentEx{
	public void view1() {
		System.out.println("parent class");
	}
}
class ChildEx extends ParentEx{
	public void view2() {
		System.out.println("child class");
	}
}
public class InheriEx1 {
	public static void main(String[] args) {
		ChildEx ob=new ChildEx();
		ob.view1();
		ob.view2();
	}
}
*/










