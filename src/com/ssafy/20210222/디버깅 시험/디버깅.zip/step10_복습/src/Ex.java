import java.util.Scanner;

public class Ex {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String a=sc.nextLine();
		int b=sc.nextInt();
		float c=sc.nextFloat();
		char d=sc.next().charAt(0);
	}
}
