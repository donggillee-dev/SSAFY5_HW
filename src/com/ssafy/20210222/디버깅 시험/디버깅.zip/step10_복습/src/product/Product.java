package product;

/*Ŭ������ : Product
 * 
 * -item:String
 * -cost:int
 * 
 * +Product()
 * +Product(item:String,cost:int)
 * +toString():String 
 */

public class Product {
	private String item;
	private int cost;

	public Product() {

	}
	public Product(String item, int cost) {
		this.item = item;
		this.cost = cost;
	}
	public String getItem() {
		return item;
	}
	public int getCost() {
		return cost;
	}
	public String toString() {
		return "��ǰ�� : " + item + "\n���� : " + cost;
	}
}
