package login;

/* 클래스명 : Login
-id:String
-pwd:String
-name:String

+Login()
+Login(id:String,pwd:String,name:String)
+setter & getter
+toString():String
*/
class Login
{
	private String id;
	private String pwd;
	private String name;
	
	public Login() {
		super();
	}
	public Login(String id, String pwd, String name) {
		super();
		this.id = id;
		this.pwd = pwd;
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return name+"의 아이디는 "+id+"이고 비밀번호는 "+pwd+"입니다";
	}
}











