package override;

class Test1{
	public void view1() { System.out.println("view1 method"); }
	public void view3() { System.out.println("view2 method"); }
}
class Test2 extends Test1{
	@Override
	public void view1() { System.out.println("view3 method"); }
	public void view2() { System.out.println("view4 method"); }
}
public class OverrideEx {
	public static void main(String[] args) {
		Test1 ob=new Test2();
		ob.view1();          // view3
//		ob.view2();          // error
		ob.view3();          // view2
		
		
//		Test2 ob=new Test2();
//		ob.view1();          // view3
//		ob.view2();          // view4
//		ob.view3();          // view2
	}
}





