package abstractex;

abstract class AA{
	public void view1() {}
	abstract public void view2();   // <----�߻�
}
class BB extends AA{
	@Override
	public void view2() {  //The type BB must implement the inherited abstract method AA.view2()

	}
}
public class AbstractEx {
	public static void main(String[] args) {
//		AA ob1=new AA();       -- ��ü ����X
		
		BB ob2=new BB();
		
		AA ob3=new BB();
	}
}
