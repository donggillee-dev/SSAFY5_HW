package objectex;

/* Ŭ������: Student
 * -name:String
 * -kor:int
 * -eng:int
 * -mat:int
 * 
 * +setter & getter
 * +getTotal():int
 * +getAvg():double
 */
class Student{
	private String name;
	private int kor;
	private int eng;
	private int mat;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getKor() {
		return kor;
	}
	public void setKor(int kor) {
		this.kor = kor;
	}
	public int getEng() {
		return eng;
	}
	public void setEng(int eng) {
		this.eng = eng;
	}
	public int getMat() {
		return mat;
	}
	public void setMat(int mat) {
		this.mat = mat;
	}
	public int getTotal() {
		return kor+eng+mat;
	}
	public double getAvg() {
		return (double)getTotal()/3;
	}	
}
public class ObjectEx4 {
	public static void main(String[] args) {
		Student ob=new Student();
		ob.setName("ȫ�浿");
		ob.setKor(90);
		ob.setEng(96);
		ob.setMat(100);
		
		System.out.println("�̸�:"+ob.getName());
		System.out.println("����:"+ob.getTotal()+"��");
		System.out.printf("���:%.2f��\n",ob.getAvg());
	}
}
/*
�̸� : ȫ�浿
���� : 286��
��� : 95.33��
*/