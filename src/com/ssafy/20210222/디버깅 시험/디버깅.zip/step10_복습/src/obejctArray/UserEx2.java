package obejctArray;

//������Ʈ�迭
public class UserEx2 {
	public static void main(String[] args) {
		User[] ob=new User[] {new User("ȫ�浿",25),
							  new User("�̼���",22),
							  new User("�ε鷡",21)};
		for(User m:ob)
		{
			System.out.println(m.getName()+"  "+m.getAge());
		}
		//----------------------------------------------------------
/*
		User[] ob=new User[3];
		ob[0]=new User("ȫ�浿",25);
		ob[1]=new User("�̼���",22);
		ob[2]=new User("�ε鷡",21);
		
		for(int i=0; i<ob.length;i++)
		{
			System.out.println(ob[i].getName()+"  "+ob[i].getAge());
		}
*/		
	}
}
