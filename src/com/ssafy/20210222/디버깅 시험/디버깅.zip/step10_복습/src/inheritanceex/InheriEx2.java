package inheritanceex;

class AA{
	public AA(int n) {
		System.out.println(n +" AA constructor");
	}
}
class BB extends AA{
	public BB() {
		this("Hello",100);
		System.out.println("default BB constructor");
	}
	public BB(String s, int n) {
		super(n);
		System.out.println(s+" " +n +" BB constructor");
	}
}
public class InheriEx2 {
	public static void main(String[] args) {
		new BB();
	}
}

//-----------------------------------------------
/*
class AA{
	public AA() {
		System.out.println("default AA class");
	}
	public AA(String str) {
		this();
		System.out.println(str + " AA class");
	}
}
class BB extends AA{
	public BB(String str) {
		super(str);
		System.out.println(str + " BB class");
	}
}
public class InheriEx2 {
	public static void main(String[] args) {
		new BB("Hello");
	}
}
*/