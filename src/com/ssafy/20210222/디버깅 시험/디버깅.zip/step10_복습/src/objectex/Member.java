package objectex;

/* Ŭ������:Member
 * -name:String
 * -socialNo:String
 * -addr:String
 * 
 * +setter& getter
 * +setMember(name:String,socialNo:int,addr:String):void
 * +getYear():int
 * +getMonth():int
 * +getDay():int
 * +getGender():char
 * +toString():String
 */
public class Member {
	private String name;
	private String socialNo;
	private String addr;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSocialNo() {
		return socialNo;
	}
	public void setSocialNo(String socialNo) {
		this.socialNo = socialNo;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public int getYear() {
		return Integer.parseInt(socialNo.substring(0,2));
	}
	public int getMonth() {
		return Integer.parseInt(socialNo.substring(2,4));
	}
	public int getDay() {
		return Integer.parseInt(socialNo.substring(4,6));
	}
	public char getGender() {
		return socialNo.charAt(7);
	}
	public void setMember(String name,String socialNo,String addr) {
		this.name=name;
		this.socialNo=socialNo;
		this.addr=addr;
	}
	@Override
	public String toString() {
		return name+"�� ������ "+getYear()+"�� "+getMonth()+"�� "+getDay()
		       +"���̸� "+ ((getGender()=='1')?"����":"����")+"�Դϴ�\n"
		       +"�ֹι�ȣ ���ڸ��� "+ socialNo.substring(7)+"�Դϴ�\n"
		       +"�ּҴ� "+getAddr()+"�Դϴ�";
	}
}











