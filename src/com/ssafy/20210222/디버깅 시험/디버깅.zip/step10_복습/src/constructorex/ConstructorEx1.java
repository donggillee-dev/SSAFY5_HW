package constructorex;

class Example{
	Example(){
		System.out.println("default constructor");
	}
	Example(String str){
		System.out.println(str+" constructor");
	}
	Example(String str, int n){
		System.out.println(str+"  "+n +" constructor");
	}
}
public class ConstructorEx1 {
	public static void main(String[] args) {
		new Example();
		new Example("Hello");
		new Example("Hello",100);
	}
}
