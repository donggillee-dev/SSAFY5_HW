package login;

class LoginMain 
{
	public static void main(String[] args) 
	{
		Login user1=new Login("tochi","5678","또치");
		//여기에 작성하시오
		System.out.println(user1.toString());

		Login user2=new Login("dulri","1234","둘리");
		//여기에 작성하시오
		System.out.println("아이디 :"+user2.getId());
		System.out.println("비밀번호 :"+user2.getPwd());
		System.out.println("이름 :"+user2.getName());
	}
}
/*
또치의 아이디는 tochi이고 비밀번호는 5678입니다   <-- toString()메서드 이용

이   름 : 둘리          <--getter를 이용해서 작성
아이디 : dulri
비   번 : 1234
*/

