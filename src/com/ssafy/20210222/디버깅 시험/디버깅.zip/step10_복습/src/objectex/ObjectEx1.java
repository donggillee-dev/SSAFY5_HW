package objectex;

//�����Ҽ� �ִ°͵�

class Test{
	public String str="Hello";
	
	public void view() {
		System.out.println(str);
	}
}
public class ObjectEx1{
	public static void main(String[] args) {
		new Test().view();
	}
}
//-------------------------------------------------
/*
import java.lang.System;
import java.lang.String;

class Test extends Object{
	public String str="Hello";
	
	public Test() {
		super();
	}
	public void view() {
		System.out.println(this.str.toString());
	}
}
public class ObjectEx1 extends Object{
	public static void main(String[] args) {
		Test ob=new Test();
		ob.view();
	}
}
*/
