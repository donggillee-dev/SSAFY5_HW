package product;

/*Ŭ������ : ProductSales
 * 
 * -qty:int
 * 
 * +ProductSales()
 * +ProductSales(item:String,cost:int,qty:int)
 * +toString():String 
 */
public class ProductSales extends Product {
	private int qty;

	public ProductSales() {

	}
	public ProductSales(String item, int cost, int qty) {
		super(item, cost);
		this.qty = qty;
	}

	public String toString() {
		return super.toString()
		        + "\n���� : " + qty + "\n�ݾ� : " + (getCost() * qty);
	}

}
