package test2;

import java.util.Stack;

/* wait()�� notify()�� �̿��Ͽ� �ϼ�
	
	Stack store=new Stack();

    pop()   :  ���� 
    push()  :  �ֱ�
*/
public class VendingMachine {
	Stack store=new Stack(); 
	
	//For coustomer(�Һ�)
	public synchronized String getDrink(){
		while(store.isEmpty())
		{
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}		
		}
		return store.pop().toString();
	}
	
	//For producer(����)
	public synchronized void putDrink(String drink){
		notify();
		store.push(drink);
	}	
}











