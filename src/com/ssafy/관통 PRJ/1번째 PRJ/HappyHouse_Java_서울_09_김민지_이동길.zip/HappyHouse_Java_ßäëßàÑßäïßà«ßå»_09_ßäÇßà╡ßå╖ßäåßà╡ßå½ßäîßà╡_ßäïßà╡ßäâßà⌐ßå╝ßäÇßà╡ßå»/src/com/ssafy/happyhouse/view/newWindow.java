package com.ssafy.happyhouse.view;

import java.awt.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import com.ssafy.happyhouse.model.dto.AirInfo;
import com.ssafy.happyhouse.model.dto.ShopInfo;

public class newWindow {
	private JFrame frame;
	private JLabel[] airInfoL;
	private DefaultTableModel houseModel;
	private JTable houseTable;
	private JScrollPane housePan;

	public newWindow(int flag) {
		String filename;
		if (flag == 1) {
			frame = new JFrame("주변 환경 오염 분석");
			String[] title = { "측정일자", "권역명", "측정소명", "미세먼지", "초미세먼지", "오존" };
			filename = "res/AirInfo.csv";
			setNewWindow(title, filename, flag);
			frame.setSize(700, 800);
		} else {
			frame = new JFrame("주변 상가 정보 분석");
			String[] title = { "상호명", "분류", "시군구", "동", "지번주소", "도로명주소", "위도", "경도" };
			filename = "res/Shop.csv";
			setNewWindow(title, filename, flag);
			frame.setSize(1000, 800);
		}

		frame.setResizable(true);
		frame.setVisible(true);
	}

	private void setNewWindow(String[] title, String filename, int flag) {
		JPanel rightCenter = new JPanel(new BorderLayout());
		houseModel = new DefaultTableModel(title, 20);
		houseTable = new JTable(houseModel);
		housePan = new JScrollPane(houseTable);
		houseTable.setColumnSelectionAllowed(true);
		rightCenter.add(housePan, "Center");

		frame.add(rightCenter, "Center");

		showData(title, filename, flag);
	}

	public void showData(String[] title, String filename, int flag) {
		File csvFile = new File(filename);

		if (flag == 1) {
			LinkedList<AirInfo> list = new LinkedList<>();

			boolean first = true;
			try {
				BufferedReader br = new BufferedReader(new FileReader(csvFile));
				// Charset.forName("UTF-8");
				String line = "";
				SimpleDateFormat bfFrom = new SimpleDateFormat("yyyymmdd");
				SimpleDateFormat afFrom = new SimpleDateFormat("yyyy-mm-dd");
				while ((line = br.readLine()) != null) {
					if (first) {
						first = false;
						continue;
					}
					String[] array = line.split(",");

					AirInfo inf = new AirInfo();
					Date formDt = bfFrom.parse(array[0]);
					inf.setDate(afFrom.format(formDt));
					inf.setRegionName(array[1]);
					inf.setLocName(array[2]);
					inf.setFineDust(array[3]);
					inf.setuFineDust(array[4]);
					inf.setoZone(array[5]);
					list.add(inf);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			if (list != null) {
				int i = 0;
				String[][] data = new String[list.size()][6];
				for (AirInfo info : list) {
					data[i][0] = info.getDate();
					data[i][1] = info.getRegionName();
					data[i][2] = info.getLocName();
					data[i][3] = info.getFineDust();
					data[i][4] = info.getuFineDust();
					data[i++][5] = info.getoZone();
				}
				houseModel.setDataVector(data, title);
			}
		} else {
			LinkedList<ShopInfo> list = new LinkedList<>();

			try {
				BufferedReader br = new BufferedReader(new FileReader(csvFile));
				// Charset.forName("UTF-8");
				String line = "";
				
				while ((line = br.readLine()) != null) {
				
					String[] array = line.split(",");
					ShopInfo inf = new ShopInfo();
					inf.setShopName(array[0]);
					inf.setBigCategory(array[1]);
					inf.setNameOfCity(array[2]);
					inf.setDongName(array[3]);
					inf.setAddressJib(array[4]);
					inf.setAddressDoro(array[5]);
					inf.setLaTitude(array[6]);
					inf.setLongiTude(array[7]);
					list.add(inf);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			if (list != null) {
				int i = 0;
				String[][] data = new String[list.size()][8];
				for(ShopInfo info : list) {
					data[i][0] = info.getShopName();
					data[i][1] = info.getBigCategory();
					data[i][2] = info.getNameOfCity();
					data[i][3] = info.getDongName();
					data[i][4] = info.getAddressJib();
					data[i][5] = info.getAddressDoro();
					data[i][6] = info.getLaTitude();
					data[i++][7] = info.getLongiTude();
				}
				houseModel.setDataVector(data, title);
			}
		}

	}
}