package com.ssafy.happyhouse.model.dto;

public class AirInfo {
	private String date;
	private String regionName;
	private String locName;
	private String fineDust;
	private String uFineDust;
	private String oZone;
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getRegionName() {
		return regionName;
	}
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}
	public String getLocName() {
		return locName;
	}
	public void setLocName(String locName) {
		this.locName = locName;
	}
	public String getFineDust() {
		return fineDust;
	}
	public void setFineDust(String fineDust) {
		this.fineDust = fineDust;
	}
	public String getuFineDust() {
		return uFineDust;
	}
	public void setuFineDust(String uFineDust) {
		this.uFineDust = uFineDust;
	}
	public String getoZone() {
		return oZone;
	}
	public void setoZone(String oZone) {
		this.oZone = oZone;
	}
	@Override
	public String toString() {
		return "AirInfo [date=" + date + ", regionName=" + regionName + ", locName=" + locName + ", fineDust="
				+ fineDust + ", uFineDust=" + uFineDust + ", oZone=" + oZone + "]";
	}
	
	
	
}
