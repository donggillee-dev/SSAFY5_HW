package com.ssafy.happyhouse.model.dto;

public class ShopInfo {
	private String shopName;
	private String bigCategory;
	private String nameOfCity;
	private String dongName;
	private String addressJib;
	private String addressDoro;
	private String laTitude;
	private String longiTude;

	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public String getBigCategory() {
		return bigCategory;
	}

	public void setBigCategory(String bigCategory) {
		this.bigCategory = bigCategory;
	}

	public String getNameOfCity() {
		return nameOfCity;
	}

	public void setNameOfCity(String nameOfCity) {
		this.nameOfCity = nameOfCity;
	}

	public String getDongName() {
		return dongName;
	}

	public void setDongName(String dongName) {
		this.dongName = dongName;
	}

	public String getAddressJib() {
		return addressJib;
	}

	public void setAddressJib(String addressJib) {
		this.addressJib = addressJib;
	}

	public String getAddressDoro() {
		return addressDoro;
	}

	public void setAddressDoro(String addressDoro) {
		this.addressDoro = addressDoro;
	}

	public String getLaTitude() {
		return laTitude;
	}

	public void setLaTitude(String laTitude) {
		this.laTitude = laTitude;
	}

	public String getLongiTude() {
		return longiTude;
	}

	public void setLongiTude(String longiTude) {
		this.longiTude = longiTude;
	}

	@Override
	public String toString() {
		return "ShopInfo [shopName=" + shopName + ", bigCategory=" + bigCategory + ", nameOfCity=" + nameOfCity
				+ ", dongName=" + dongName + ", addressJib=" + addressJib + ", addressDoro=" + addressDoro
				+ ", laTitude=" + laTitude + ", longiTude=" + longiTude + "]";
	}

	
}
